# coding:utf-8

import os
import sys
import torch
import torchvision
import pretrainedmodels
import matplotlib.pyplot as plt

from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.datasets import ImageFolder

data_dir = 'D:/workspace/udacity/MLND/capstone/distracted_driver_detection/data/'

train_transorms = transforms.Compose([
    transforms.CenterCrop((320, 480)),
    #transforms.RandomHorizontalFlip(p=0.5),
    transforms.ToTensor()
])
train_gen = ImageFolder(os.path.join(data_dir, 'train/'), transform=train_transorms)
train_dataiter = DataLoader(train_gen, batch_size=128, shuffle=True)

num_sampler = train_dataiter.sampler.num_samples
total_num = num_sampler * 320 * 480

r_means = torch.zeros(len(train_dataiter), dtype=torch.float32)
g_means = torch.zeros(len(train_dataiter), dtype=torch.float32)
b_means = torch.zeros(len(train_dataiter), dtype=torch.float32)

print("calc mean")
for i, train_data in enumerate(train_dataiter):
    train_images = train_data[0]
    print("[{}] mean batch".format(i))
    train_images_r = train_images[:,0,:,:]
    train_images_g = train_images[:,1,:,:]
    train_images_b = train_images[:,2,:,:]

    mean = torch.div(train_images_r.sum(), total_num)
    r_means[i] = mean
    mean = torch.div(train_images_g.sum(), total_num)
    g_means[i] = mean
    mean = torch.div(train_images_b.sum(), total_num)
    b_means[i]  = mean
    print("middle result = [{},{},{}]".format(r_means[i], g_means[i], b_means[i]))

r_mean = r_means.sum()
g_mean = g_means.sum()
b_mean = b_means.sum()

r_stds = torch.zeros(len(train_dataiter), dtype=torch.float32)
g_stds = torch.zeros(len(train_dataiter), dtype=torch.float32)
b_stds = torch.zeros(len(train_dataiter), dtype=torch.float32)

print("calc std")
for i, train_data in enumerate(train_dataiter):
    train_images = train_data[0]
    print("[{}] std batch".format(i))
    train_images_r = train_images[:,0,:,:]
    train_images_r.sub(r_mean).pow(2)
    r_stds[i] = torch.div(train_images_r.sum(), total_num)

    train_images_g = train_images[:,1,:,:]
    train_images_g.sub(g_mean).pow(2)
    g_stds[i] = torch.div(train_images_g.sum(), total_num)

    train_images_b = train_images[:,2,:,:]
    train_images_b.sub(b_mean).pow(2)
    b_stds[i] = torch.div(train_images_b.sum(), total_num)
    print("middle result = [{},{},{}]".format(r_stds[i], g_stds[i], b_stds[i]))

r_std = torch.sqrt(r_stds.sum())
g_std = torch.sqrt(g_stds.sum())
b_std = torch.sqrt(b_stds.sum())

print("mean = [{},{},{}]".format(r_mean, g_mean, b_mean))
print("std = [{},{},{}]".format(r_std, g_std, b_std))













