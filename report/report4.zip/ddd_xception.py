# coding:utf-8
import os
import sys
import cv2
import csv
import fire
import time
import json
import tarfile
import torch
import torch.nn as nn
from torchvision import models
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.datasets import ImageFolder

import pretrainedmodels

from glob import glob
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
#from tensorboardX import SummaryWriter
import pdb

ON_CLIENT = True
NUM_CLASSES = 10
EPOCHS = 10
LEARN_RATE = 0.001
DROPOUT = 0.5
DEVICE_ID = 0
CROP_SIZE = (320, 480)
#MG_SIZE = (224, 224)
IMG_SIZE = (299, 299)
BATCH_SIZE = 32
IMG_MEAN = (0.31633861, 0.38164441, 0.37510719)
IMG_STD = (0.28836174, 0.32873901, 0.33058995)
DEFAULT_DEVICE_ID = 0
CUDA = torch.cuda.is_available()
DEVICE = torch.device("cpu")

data_dir = 'D:/workspace/udacity/MLND/capstone/distracted_driver_detection/data/'


class XceptionNet(nn.Module):
    def __init__(self, model=None, dropout=DROPOUT, num_classes=NUM_CLASSES):
        super(XceptionNet, self).__init__()

        if model is None:
            self.model = pretrainedmodels.__dict__[
                'xception'](pretrained='imagenet')
        else:
            self.model = model
        # self.model.to(DEVICE_CLASSIFIER)

        self.dropout = dropout
        self.num_classes = num_classes

        # self.classifier_transorms = transforms.Compose([
        #    transforms.Lambda(lambda tensors:
        #                      [transforms.Resize((299, 299))(transforms.ToPILImage()(tensor)) for tensor in tensors]),
        #    transforms.Lambda(lambda tensors:
        #                      torch.stack([transforms.ToTensor()(tensor) for tensor in tensors]))
        # ])

        # extract freature
        # self.feature = nn.Sequential(*list(self.model.children())[:-1])

        # for param in self.model.parameters():
        #    param.requires_grad = False

        in_dim = self.model.last_linear.in_features

        finetune = nn.Sequential(
            nn.Linear(in_dim, 4096),
            nn.ReLU(True),
            nn.Dropout(self.dropout),
            nn.Linear(4096, 4096),
            nn.ReLU(True),
            nn.Dropout(self.dropout),
            nn.Linear(4096, self.num_classes)
        )

        self.model.last_linear = finetune

    def forward(self, x):
        x = self.model(x)
        return x

def make_model(model_path=None, dropout=DROPOUT, on_client=ON_CLIENT):
    model = XceptionNet(
        dropout=dropout, num_classes=NUM_CLASSES)
    if model_path is not None:
        model.load_state_dict(torch.load(
            model_path, map_location=DEVICE))

    return model

# ========================================================================================================


def device_setting(on_client, id=0):
    if on_client is True:
        device_id = 'cuda:0'
    else:
        device_id = 'cuda:{}'.format(id)

    DEVICE = torch.device(device_id)
    #print('Device Id = {}'.format(DEVICE))
    return DEVICE


def make_transorms():
    train_transorms = transforms.Compose([
        transforms.CenterCrop(CROP_SIZE),
        #transforms.RandomAffine(degrees=10, translate=(0.1, 0.3)),
        # transforms.RandomHorizontalFlip(),
        # transforms.RandomResizedCrop(IMG_SIZE),
        transforms.Resize(IMG_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(IMG_MEAN, IMG_STD)
    ])

    valid_transorms = transforms.Compose([
        transforms.CenterCrop(CROP_SIZE),
        transforms.Resize(IMG_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(IMG_MEAN, IMG_STD)
    ])
    return train_transorms, valid_transorms

def default_transorms():
    return transforms.Compose([
        transforms.CenterCrop(CROP_SIZE),
        transforms.Resize(IMG_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(IMG_MEAN, IMG_STD)
    ])

def get_datasets(train_data_dir, valid_data_dir=None, 
                 train_transorms=None, valid_transorms=None,
                 batch_size=BATCH_SIZE):
    #train_data_dir = os.path.abspath(train_data_dir)
    #valid_data_dir = os.path.abspath(valid_data_dir)

    if train_transorms is None:
        train_transorms = default_transorms()

    train_gen = ImageFolder(train_data_dir, transform=train_transorms)
    if valid_transorms is not None:
        valid_gen = ImageFolder(valid_data_dir, transform=valid_transorms)
    train_dataiter = DataLoader(train_gen, batch_size=batch_size, shuffle=True)
    return train_dataiter, valid_gen


def valid(model, criterion, valid_dataset, device=DEVICE):
    model.eval()

    loss = 0
    correct = 0

    with torch.no_grad():
        for i, data in enumerate(valid_dataset):
            image = data[0]
            label = torch.tensor(data[1], dtype=torch.long)

            image = torch.unsqueeze(image, 0)
            label = torch.unsqueeze(label, 0)

            image = image.to(device)
            label = label.to(device)

            pred = model(image)
            loss += criterion(pred, label).item()
            pred = pred.max(1, keepdim=True)[1]
            correct += pred.eq(
                label.view_as(pred)).sum().item()
    loss /= len(valid_dataset)
    return loss, correct


def train_nn(model, criterion, optimizer, train_dataiter, device=DEVICE):
    model.train()

    for batch_index, train_data in enumerate(train_dataiter):
        images = train_data[0]
        labels = train_data[1]

        # copy CPU data to GPU
        images = images.to(device)
        labels = labels.to(device)
        #image = torch.unsqueeze(image.to(DEVICE), 0)
        #label = torch.unsqueeze(label.to(DEVICE), 0)

        optimizer.zero_grad()
        pred = model(images)

        loss = criterion(pred, labels)
        loss.backward()
        optimizer.step()
    return loss


def train(model, task_name, train_data_dir, valid_data_dir, basic_model_save_path=None, epochs=EPOCHS, 
          batch_size=BATCH_SIZE, learn_rate=LEARN_RATE, dropout=DROPOUT, save_dir='../model', 
          show_model=False, zipit=False, on_client=ON_CLIENT, last_accuracy=0.0, device=DEVICE):
    """
    trainning...
    """
    screen_print = []
    #datas_id = str(device).split(':')[1]

    def printf(str):
        if str is None:
            print()
            screen_print.append('\n')
        else:
            print(str)
            screen_print.append(str+'\n')

    train_data_dir = os.path.abspath(train_data_dir)
    valid_data_dir = os.path.abspath(valid_data_dir)
    save_dir = os.path.abspath(save_dir)

    printf('===== TRAIN INFO =====')
    printf('task name = {}'.format(task_name))
    printf('train data dir = {}'.format(train_data_dir))
    printf('valid data dir = {}'.format(valid_data_dir))
    printf('basic model save path = {}'.format(basic_model_save_path))
    printf('dropout = {}'.format(dropout))
    printf('epochs = {}'.format(epochs))
    printf('learn rate = {}'.format(learn_rate))
    printf('batch size = {}'.format(batch_size))
    printf('save dir = {}'.format(save_dir))
    printf('zip it = {}'.format(zipit))
    printf('on client = {}'.format(on_client))
    printf('last accuracy = {}'.format(last_accuracy))

    printf('===== DEVICE INFO =====')
    printf(str(device))
    printf('======================')

    EPOCHS = epochs
    BATCH_SIZE = batch_size
    LEARN_RATE = learn_rate
    DROPOUT = dropout
    ON_CLIENT = on_client

    train_transorms, valid_transorms = make_transorms()
    train_dataiter, valid_dataset = get_datasets(train_data_dir, valid_data_dir,
        train_transorms, valid_transorms, batch_size)
    print('[INFO]generate datasets ok')

    if show_model is True:
        print(model)
        print()

    # RMSprop
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learn_rate)
    model_save_path = None

    timestamp = time.asctime()
    print('[INFO]start at {}'.format(timestamp))
    timestamp = timestamp.replace(' ', '_').replace(':', '_')

    best_valid_accuracy = last_accuracy
    for epoch in range(1, epochs+1):
        printf('Trainning: {}\n'.format(epoch))

        loss = train_nn(model, criterion, optimizer,
                        train_dataiter, device=device)
        printf('Train Epoch: {}\t Loss: {:.6f}\n'.format(epoch, loss.item()))

        valid_loss, correct = valid(
            model, criterion, valid_dataset, device=device)
        printf('Valid set: Average of loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
            valid_loss, correct, len(valid_dataset), 100. * correct / len(valid_dataset)))

        curr_valid_accuracy = correct / len(valid_dataset)
        if (curr_valid_accuracy > best_valid_accuracy):
            printf('Now best model: Average of loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
                valid_loss, correct, len(valid_dataset), 100. * correct / len(valid_dataset)))

            if model_save_path is not None:
                os.remove(model_save_path)

            # model save file name = 'task name' + '_' + timestamp
            timestamp = time.asctime().replace(' ', '_').replace(':', '_')
            model_save_path = os.path.join(
                save_dir, task_name+'_'+timestamp+'.pth')
            torch.save(model.state_dict(), model_save_path)
            best_valid_accuracy = curr_valid_accuracy

    if model_save_path is None:
        # model_save_path is none and basic_model_save_path is None, it's not possible!!!
        # beacuse last_accuracy init value is 0.0.
        model_save_path = basic_model_save_path

    if basic_model_save_path is None:
        basic_model_save_path = model_save_path

    print_save_path = os.path.join(save_dir, task_name+'_'+timestamp+'.txt')
    f = open(print_save_path, 'w')
    for line in screen_print:
        f.write(line)
    f.close()

    if best_valid_accuracy > last_accuracy:
        print('save model to {}'.format(model_save_path))
    elif basic_model_save_path is not None:
        print('use basic model save path {}'.format(basic_model_save_path))
    else:
        print('accuracy not improve')
    print('best valid accuracy: {:.4f}'.format(best_valid_accuracy))

    new_checkpoint_path = os.path.join(
        save_dir, task_name+'_'+timestamp+'.json')
    with open(new_checkpoint_path, "w") as f:
        state_dict = {
            'task_name': task_name,
            'best_valid_accuracy': best_valid_accuracy,
            'basic_model_save_path' : basic_model_save_path,
            'model_path': model_save_path,
            'info_path': print_save_path,
            'learn_rate': learn_rate,
            'batch_size': batch_size,
            'dropout': dropout
        }
        json.dump(state_dict, f)

    if zipit is True:
        tarfile_path = os.path.join(
            save_dir, task_name+'_'+timestamp+'.tar.gz')
        with tarfile.open(tarfile_path, "w:gz") as tar:
            tar.add(print_save_path)
            tar.add(new_checkpoint_path)
            tar.add(model_save_path)
            tar.close()

    print('please use checkpoint file "{}"'.format(new_checkpoint_path))
    return True


class TestDataset(Dataset):
    def __init__(self, data_dir, device=DEVICE):
        super(TestDataset, self).__init__()
        self.image_paths = glob(os.path.join(data_dir, '*.jpg'))
        _, test_transorms = make_transorms()
        self.transorms = test_transorms
        print('{} number of test image loaded.'.format(len(self.image_paths)))
        self.device = device

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, index):
        # assert index >= len(self.image_paths), 'index, out of range'

        path = self.image_paths[index]
        image = Image.open(path)
        image_tensor = self.transorms(image)
        image_tensor_gpu = torch.tensor(image_tensor, device=self.device)
        # image_tensor = transforms.functional.to_tensor(image)
        filename = os.path.basename(path)

        return (image_tensor_gpu, filename)


def generate_csv_handle(csv_path='./test.csv'):
    header = ['img', 'c0', 'c1', 'c2', 'c3',
              'c4', 'c5', 'c6', 'c7', 'c8', 'c9']
    csv_file = open(csv_path, 'w')
    csv_write = csv.writer(csv_file)
    csv_write.writerow(header)
    return csv_file, csv_write


def test(model, data_dir, csv_path='./result.csv', batch_size=BATCH_SIZE,
         on_client=ON_CLIENT, device=DEVICE):
    data_dir = os.path.abspath(data_dir)
    csv_path = os.path.abspath(csv_path)
    csv_file, csv_write = generate_csv_handle(csv_path)

    test_gen = TestDataset(os.path.join(data_dir, 'test/'), device=device)
    test_dataiter = DataLoader(test_gen, batch_size=batch_size, shuffle=False)
    print('[INFO]generate datasets ok')

    BATCH_SIZE = batch_size
    ON_CLIENT = on_client

    model.eval()
    with torch.no_grad():
        for i, data in enumerate(test_dataiter):
            print('Test {}th batch'.format(i))
            print()

            images = data[0]
            filenames = data[1]

            pred = model(images)
            pred = torch.nn.functional.softmax(pred, dim=0)
            pred = pred.cpu().clone().detach().numpy()

            row = []
            for (filename, prob) in zip(filenames, pred):
                row.append(filename)
                row.extend(prob)
                csv_write.writerow(row)
                row.clear()

    csv_file.close()
    print('save csv to {}'.format(csv_path))


def run(command, task_name, train_data_dir, valid_data_dir=None, checkpoint_path=None, epochs=EPOCHS,
        learn_rate=LEARN_RATE, dropout=DROPOUT, batch_size=BATCH_SIZE, save_dir='../model',
        show_model=False, csv_path='./result.csv', zipit=False, on_client=ON_CLIENT,
        device=DEFAULT_DEVICE_ID):
    """
    command: train, test
    """
    DEVICE = device_setting(on_client, device)

    model_path = None
    last_accuracy = 0.0
    if checkpoint_path is not None:
        with open(checkpoint_path, 'r') as load_f:
            config = json.load(load_f)
            model_path = config['model_path']
            last_accuracy = config['best_valid_accuracy']

    model = make_model(model_path, dropout=dropout, on_client=on_client)
    model = model.to(DEVICE)

    if command == 'train':
        if valid_data_dir is None:
            valid_data_dir = train_data_dir
        train(model, task_name=task_name, train_data_dir=train_data_dir, valid_data_dir=valid_data_dir, 
              basic_model_save_path=model_path, epochs=epochs, batch_size=batch_size, learn_rate=learn_rate, 
              dropout=dropout, save_dir=save_dir, show_model=show_model, zipit=zipit, on_client=on_client,
              last_accuracy=last_accuracy, device=DEVICE)
        return True

    if command == 'test':
        test(model, data_dir=train_data_dir, batch_size=batch_size,
             csv_path=csv_path, on_client=on_client, device=DEVICE)
        return True

    print('invalid command')
    return False


def bagging_valid(models, criterion, valid_dataset, devices):
    loss = 0
    correct = 0
    preds = []

    with torch.no_grad():
        for i, data in enumerate(valid_dataset):
            image = data[0]
            label = torch.tensor(data[1], dtype=torch.long)

            image = torch.unsqueeze(image, 0)
            label = torch.unsqueeze(label, 0)
            label_clone = label.clone()
            preds.clear()

            for i, model in enumerate(models):
                device = devices[i]
                image = image.to(device)
                label = label.to(device)
                pred = model(image)
                preds.append(pred.cuda().data.cpu().numpy())

            preds_tensor = torch.tensor(preds, dtype=torch.float64)
            preds_mean = preds_tensor.mean(dim=0)
            loss += criterion(preds_mean, label_clone).item()
            pred = preds_mean.max(1, keepdim=True)[1]
            correct += pred.eq(
                label_clone.view_as(pred)).sum().item()
    loss /= len(valid_dataset)
    return loss, correct


def bagging_test(valid_data_dir, cpp1, cpp2, cpp3, cpp4):
    models = []
    devices = []

    checkpoint_paths = [cpp1, cpp2, cpp3, cpp4]
    for i, checkpoint_path in enumerate(checkpoint_paths):
        model_path = None
        print('[INFO]read checkpoint: {}'.format(checkpoint_path))
        with open(checkpoint_path, 'r') as load_f:
            config = json.load(load_f)
            model_path = config['model_path']
            print('      read model: {}'.format(model_path))
        model = make_model(model_path, on_client=False)

        device_id = 'cuda:{}'.format(i)
        device = torch.device(device_id)
        model = model.to(device)
        model.eval()
        models.append(model)
        devices.append(device)

    print('[INFO]models generated')

    valid_transorms = default_transorms()
    valid_dataiter = ImageFolder(valid_data_dir, transform=valid_transorms)
    print('[INFO]generate datasets ok')

    criterion = torch.nn.CrossEntropyLoss()
    loss, correct = bagging_valid(models, criterion, valid_dataiter, devices)
    print('Valid set: Average of loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        loss, correct, len(valid_dataiter), 100. * correct / len(valid_dataiter)))


#bagging_test('D:/workspace/udacity/MLND/capstone/distracted_driver_detection/data/bagging/valid', 
#            'model1', 'model2', 'model3', 'model4')
# checkpoint_path=data_dir+'../model/masker_Sat_May__4_21_28_36_2019.json'
#run(command='train', data_dir=data_dir, on_client=True, device=1)
# ========================================================================================================
if __name__ == '__main__':
    fire.Fire()
