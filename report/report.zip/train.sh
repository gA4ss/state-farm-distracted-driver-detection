#!/bin/bash
python ./ddd_xvgg.py train --data_dir=../data --save_dir=../model --epochs=10 --learn_rate=0.001 --batch_size=8 --dropout=0.5