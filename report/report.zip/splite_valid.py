# coding:utf-8

import os
import pandas as pd
import numpy as np
import shutil
import random
import inspect
from glob import glob

def splite_valid():

    base_dir = os.path.abspath(os.path.join(inspect.getfile(splite_valid), os.pardir))
    data_dir = os.path.join(base_dir, "../data/")

    driver_imgs_list_csv = os.path.join(data_dir, "driver_imgs_list.csv")
    df = pd.read_csv(driver_imgs_list_csv)
    #subjects = list(set(df["subject"]))
    #select = random.sample(range(len(subjects)), 2)
    valid_subjects = ['p002', 'p047']

    print(valid_subjects)

    if not os.path.exists(data_dir + "valid"):
        os.mkdir(data_dir + "valid")
        for i in range(10):
            os.mkdir(data_dir + "valid/c%d"%i)

    for valid_subject in valid_subjects:
        df_valid = df[(df["subject"]==valid_subject)]
        for index, row in df_valid.iterrows():
            subpath = row["classname"] + "/" + row["img"]
            if os.path.exists(os.path.join(data_dir,"train",subpath)):
                shutil.move(os.path.join(data_dir,"train",subpath), os.path.join(data_dir,"valid",subpath),)
            else:
                print("cannot move {} : {}".format(row["subject"],subpath))


def data_recover():
    base_dir = os.path.abspath(os.path.join(inspect.getfile(data_recover), os.pardir))
    data_dir = os.path.join(base_dir, "../data/")
    for i in range(10):
        path = data_dir + "valid/c%d/"%i
        file_paths = glob(os.path.join(path, "*.jpg"))
        for path in file_paths:
            file_name = os.path.basename(path)
            to_file_path = data_dir + "train/c%d/%s" % (i, file_name)
            #print("move %s to %s"%(path, to_file_path))
            shutil.move(path, to_file_path,)

#data_recover()
splite_valid()