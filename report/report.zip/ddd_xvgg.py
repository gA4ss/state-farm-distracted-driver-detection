# coding:utf-8
"""
"""
import os
import sys
import csv
import fire
import time
import torch
import torch.nn as nn
from torchvision import models
from torchvision.models.vgg import VGG
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.datasets import ImageFolder

import pretrainedmodels

from glob import glob
from PIL import Image

data_dir = 'D:/workspace/udacity/MLND/capstone/distracted_driver_detection/data/'

ON_CLIENT = False
DEVICE_ID = 0
EPOCHS = 10
DROPOUT = 0.5
NUM_CLASSES = 10
LEARN_RATE = 0.001
CROP_SIZE = (320, 480)
IMG_SIZE = (299, 299)
BATCH_SIZE = 1
IMG_MEAN = (0.3184719383716583, 0.3813590109348297, 0.37875279784202576)
IMG_VAR = (0.3184719383716583, 0.3813589811325073, 0.37875282764434814)
IMG_STD = (0.5643, 0.6175, 0.6154)

CUDA = torch.cuda.is_available()
# DEVICE = torch.device("cuda" if CUDA else "cpu")

DEVICE_MASKER = torch.device("cuda:1")
DEVICE_CLASSIFIER = torch.device("cuda:2")
DEVICE_TEST = torch.device("cpu")

if ON_CLIENT is True:
    DEVICE_MASKER = torch.device("cuda:0")
    DEVICE_CLASSIFIER = torch.device("cpu")
    DEVICE_TEST = torch.device("cpu")

ranges = {
    'vgg11': ((0, 3), (3, 6),  (6, 11),  (11, 16), (16, 21)),
    'vgg13': ((0, 5), (5, 10), (10, 15), (15, 20), (20, 25)),
    'vgg16': ((0, 5), (5, 10), (10, 17), (17, 24), (24, 31)),
    'vgg19': ((0, 5), (5, 10), (10, 19), (19, 28), (28, 37))
}

cfg = {
    'vgg11': [64, 'M', 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'vgg13': [64, 64, 'M', 128, 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'vgg16': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 'M', 512, 512, 512, 'M', 512, 512, 512, 'M'],
    'vgg19': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 256, 'M', 512, 512, 512, 512, 'M', 512, 512, 512, 512, 'M'],
}


def make_layers(cfg, batch_norm=False):
    layers = []
    in_channels = 3
    for v in cfg:
        if v == 'M':
            layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
        else:
            conv2d = nn.Conv2d(in_channels, v, kernel_size=3, padding=1)
            if batch_norm:
                layers += [conv2d, nn.BatchNorm2d(v), nn.ReLU(inplace=True)]
            else:
                layers += [conv2d, nn.ReLU(inplace=True)]
            in_channels = v
    return nn.Sequential(*layers)


class VGGNet(VGG):
    def __init__(self, pretrained=True, model='vgg16'):
        super().__init__(make_layers(cfg[model]))
        self.ranges = ranges[model]

        if pretrained:
            exec("self.load_state_dict(models.%s(pretrained=True).state_dict())" % model)

    def forward(self, x):
        output = {}
        # get the output of each maxpooling layer (5 maxpool in VGG net)
        for idx, (begin, end) in enumerate(self.ranges):
            # self.ranges = ((0, 5), (5, 10), (10, 17), (17, 24), (24, 31)) (vgg16 examples)
            for layer in range(begin, end):
                x = self.features[layer](x)
            output["x%d" % (idx+1)] = x

        return output


class MaskNet(nn.Module):
    def __init__(self, model=None):
        super(MaskNet, self).__init__()

        if model is None:
            self.model = VGGNet()
        else:
            self.model = model
        # self.model.to(DEVICE_MASKER)

        for param in self.model.parameters():
            param.requires_grad = False

        self.relu = nn.ReLU(inplace=True)
        self.deconv1 = nn.ConvTranspose2d(
            512, 512, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn1 = nn.BatchNorm2d(512)
        self.deconv2 = nn.ConvTranspose2d(
            512, 256, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn2 = nn.BatchNorm2d(256)
        self.deconv3 = nn.ConvTranspose2d(
            256, 128, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn3 = nn.BatchNorm2d(128)
        self.deconv4 = nn.ConvTranspose2d(
            128, 64, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn4 = nn.BatchNorm2d(64)
        self.deconv5 = nn.ConvTranspose2d(
            64, 32, kernel_size=3, stride=2, padding=1, dilation=1, output_padding=1)
        self.bn5 = nn.BatchNorm2d(32)

        self.masker = nn.Sequential(
            nn.Conv2d(32, 16, kernel_size=1),
            nn.Conv2d(16, 8, kernel_size=1),
            nn.Conv2d(8, 3, kernel_size=1)
        )

        self.excessive = nn.Conv2d(3, 1, kernel_size=1)

        self.classifier = nn.Sequential(
            nn.Dropout(DROPOUT),
            nn.Linear(153600, 2048),
            nn.ReLU(True),
            # nn.Dropout(),
            # nn.Linear(76800, 1000),
            # nn.ReLU(True),
            nn.Dropout(DROPOUT),
            nn.Linear(2048, NUM_CLASSES)
        )

    def forward(self, x):
        output = self.model(x)
        x5 = output['x5']
        x4 = output['x4']
        x3 = output['x3']
        x2 = output['x2']
        x1 = output['x1']

        mask = self.bn1(self.relu(self.deconv1(x5)))
        #mask = mask + x4
        mask = self.bn2(self.relu(self.deconv2(mask)))
        #mask = mask + x3
        mask = self.bn3(self.relu(self.deconv3(mask)))
        #mask = mask + x2
        mask = self.bn4(self.relu(self.deconv4(mask)))
        #mask = mask + x1
        mask = self.bn5(self.relu(self.deconv5(mask)))
        self.mask = self.masker(mask)

        #img = transforms.functional.to_pil_image(self.mask)
        #img.show()

        self.feature_image = self.excessive(self.mask)

        x = self.feature_image.view(self.feature_image.size(0), -1)
        pred = self.classifier(x)

        return pred


class ClassifierNet(nn.Module):
    def __init__(self, model=None):
        super(ClassifierNet, self).__init__()

        if model is None:
            self.model = pretrainedmodels.__dict__[
                'xception'](pretrained='imagenet')
        else:
            self.model = model
        # self.model.to(DEVICE_CLASSIFIER)

        # extract freature
        # self.feature = nn.Sequential(*list(self.model.children())[:-1])

        for param in self.model.parameters():
            param.requires_grad = False

        in_dim = self.model.last_linear.in_features

        finetune = nn.Sequential(
            nn.Dropout(DROPOUT),
            nn.Linear(in_dim, 1000),
            nn.ReLU(True),
            nn.Dropout(DROPOUT),
            nn.Linear(1000, NUM_CLASSES)
        )

        self.model.last_linear = finetune

    def forward(self, x):
        x = self.model(x)
        return x


"""
class XVggNet(nn.Module):
    def __init__(self, mmodel, cmodel):
        super(XVggNet, self).__init__()

        self.mmodel = mmodel
        # self.mmodel.to(DEVICE_MASKER)

        self.cmodel = cmodel
        # self.cmodel.to(DEVICE_CLASSIFIER)

    def forward(self, x):
        mask = self.mmodel(x)
        pred = self.cmodel(mask)
        return pred
"""


def make_transorms():
    train_transorms = transforms.Compose([
        transforms.CenterCrop(CROP_SIZE),
        # transforms.RandomAffine(degrees=10, translate=(0.1, 0.3)),
        # transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(IMG_MEAN, IMG_STD)
    ])

    valid_transorms = transforms.Compose([
        transforms.CenterCrop(CROP_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(IMG_MEAN, IMG_STD)
    ])

    return train_transorms, valid_transorms


def get_datasets(data_dir, train_transorms, valid_transorms=None, batch_size=BATCH_SIZE):
    valid_gen = None
    train_gen = ImageFolder(os.path.join(
        data_dir, 'train/'), transform=train_transorms)
    if valid_transorms is not None:
        valid_gen = ImageFolder(os.path.join(
            data_dir, 'valid/'), transform=valid_transorms)

    train_dataiter = DataLoader(train_gen, batch_size=batch_size, shuffle=True)
    return train_dataiter, valid_gen


def make_model(masker_path=None, classifier_path=None):

    if masker_path is not None:
        if ON_CLIENT:
            masker_model = torch.load(masker_path, map_location=torch.device('cpu'))
        else:
            masker_model = torch.load(masker_path)
    else:
        masker_model = MaskNet()

    if classifier_path is not None:
        if ON_CLIENT:
            classifier_model = torch.load(classifier_path, map_location=torch.device('cpu'))
        else:
            classifier_model = torch.load(classifier_path)
    else:
        classifier_model = ClassifierNet()

    # model = XVggNet(masker_model, classifier_model)
    return masker_model, classifier_model


def valid(masker_model, classifier_model, masker_criterion, classifier_criterion, datasets):
    masker_model.eval()
    classifier_model.eval()

    loss = 0
    correct = 0

    with torch.no_grad():
        for i, data in enumerate(datasets):
            image = data[0]
            label = torch.tensor(data[1], dtype=torch.long)

            image = torch.unsqueeze(image.to(DEVICE_MASKER), 0)
            label = torch.unsqueeze(label.to(DEVICE_CLASSIFIER), 0)

            masker_pred = masker_model(image)
            masker_output = masker_model.mask

            classifier_input = torch.as_tensor(
                masker_output, device=DEVICE_CLASSIFIER)
            classifier_pred = classifier_model(classifier_input)

            loss += classifier_criterion(classifier_pred, label).item()
            pred = classifier_pred.max(1, keepdim=True)[1]

            correct += pred.eq(label.view_as(pred)).sum().item()
    loss /= len(datasets)
    return loss, correct


def train_nn(masker_model, classifier_model, masker_criterion, classifier_criterion,
             masker_optimizer, classifier_optimizer, train_dataiter):
    for batch_index, train_data in enumerate(train_dataiter):
        train_images_masker = train_data[0]
        train_labels_masker = train_data[1]
        train_labels_classifier = train_data[1]

        # copy CPU data to GPU
        train_images_masker = train_images_masker.to(DEVICE_MASKER)
        train_labels_masker = train_labels_masker.to(DEVICE_MASKER)

        train_labels_classifier = train_labels_classifier.to(DEVICE_CLASSIFIER)

        masker_optimizer.zero_grad()
        classifier_optimizer.zero_grad()

        masker_pred = masker_model(train_images_masker)
        masker_output = masker_model.mask

        classifier_input = torch.as_tensor(
            masker_output, device=DEVICE_CLASSIFIER)
        classifier_pred = classifier_model(classifier_input)

        classifier_loss = classifier_criterion(
            classifier_pred, train_labels_classifier)
        classifier_loss.backward(retain_graph=True)

        # use classifier's pred to train masker
        masker_loss = masker_criterion(masker_pred, train_labels_masker)
        masker_loss.backward()

        classifier_optimizer.step()
        masker_optimizer.step()
    return masker_loss, classifier_loss


def train(data_dir=data_dir, masker_path=None, classifier_path=None, epochs=EPOCHS, learn_rate=LEARN_RATE,
          batch_size=BATCH_SIZE, dropout=DROPOUT, save_dir='../model', show_model=False):

    data_dir = os.path.abspath(data_dir)
    if masker_path is not None:
        masker_path = os.path.abspath(masker_path)
    if classifier_path is not None:
        classifier_path = os.path.abspath(classifier_path)
    save_dir = os.path.abspath(save_dir)

    EPOCHS = epochs
    BATCH_SIZE = batch_size
    LEARN_RATE = learn_rate
    DROPOUT = dropout

    print('===== TRAIN INFO =====')
    print('data dir = {}'.format(data_dir))
    print('masker path = {}'.format(
        masker_path if masker_path is not None else '[new model]'))
    print('classifier path = {}'.format(
        classifier_path if classifier_path is not None else '[new model]'))
    print('epochs = {}'.format(epochs))
    print('learn rate = {}'.format(learn_rate))
    print('batch size = {}'.format(batch_size))
    print('dropout = {}'.format(dropout))
    print('save dir = {}'.format(save_dir))
    print('======================')

    print()

    train_transorms, valid_transorms = make_transorms()
    train_dataiter, valid_datasets = get_datasets(
        data_dir, train_transorms, valid_transorms, batch_size)
    print('[INFO]generate datasets ok')

    masker_model, classifier_model = make_model(masker_path, classifier_path)
    masker_model.to(DEVICE_MASKER)
    classifier_model.to(DEVICE_CLASSIFIER)
    print('[INFO]load model ok')

    if show_model is True:
        print(masker_model)
        print()
        print(classifier_model)

    # RMSprop
    masker_criterion = torch.nn.CrossEntropyLoss()
    masker_optimizer = torch.optim.Adam([{'params': masker_model.parameters()}],
                                        lr=learn_rate)

    classifier_criterion = torch.nn.CrossEntropyLoss()
    classifier_optimizer = torch.optim.Adam([{'params': classifier_model.parameters()}],
                                            lr=learn_rate)

    for epoch in range(1, epochs+1):
        print('Trainning: {}'.format(epoch))
        masker_train_loss, classifier_train_loss = train_nn(
            masker_model, classifier_model, masker_criterion, classifier_criterion,
            masker_optimizer, classifier_optimizer, train_dataiter)

        print('Train Epoch: {}\t Masker Loss: {:.6f}\t Classifier Loss: {:.6f}'.format(
            epoch, masker_train_loss.item(), classifier_train_loss.item()))

        valid_loss, correct = valid(
            masker_model, classifier_model, masker_criterion, classifier_criterion, valid_datasets)
        print('\nValid set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
            valid_loss, correct, len(valid_datasets), 100. * correct / len(valid_datasets)))

    timestamp = time.asctime().replace(' ', '_').replace(':', '_')

    masker_save_path = os.path.join(save_dir, 'xvgg_masker_'+timestamp+'.pth')
    torch.save(masker_model, masker_save_path)
    print('save masker model to {}'.format(masker_save_path))

    classifier_save_path = os.path.join(
        save_dir, 'xvgg_classifier_'+timestamp+'.pth')
    torch.save(classifier_model, classifier_save_path)
    print('save classifier model to {}'.format(classifier_save_path))


# ========================================================================================================


class TestDataset(Dataset):
    def __init__(self, data_dir):
        super(TestDataset, self).__init__()
        self.image_paths = glob(os.path.join(data_dir, '*.jpg'))
        _, test_transorms = make_transorms()
        self.transorms = test_transorms

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, index):
        #assert index >= len(self.image_paths), 'index, out of range'

        path = self.image_paths[index]
        image = Image.open(path)
        image_tensor = self.transorms(image)
        #image_tensor = transforms.functional.to_tensor(image)
        filename = os.path.basename(path)

        return (image_tensor, filename)


def generate_csv_handle(csv_path='./test.csv'):
    header = ['img', 'c0', 'c1', 'c2', 'c3',
              'c4', 'c5', 'c6', 'c7', 'c8', 'c9']
    csv_file = open(csv_path, 'w')
    csv_write = csv.writer(csv_file)
    csv_write.writerow(header)
    return csv_file, csv_write


def test(data_dir=data_dir, masker_path=None, classifier_path=None, csv_path='./result.csv'):
    datasets = 0

    data_dir = os.path.abspath(data_dir)
    if masker_path is not None:
        masker_path = os.path.abspath(masker_path)
    if classifier_path is not None:
        classifier_path = os.path.abspath(classifier_path)
    csv_path = os.path.abspath(csv_path)

    csv_file, csv_write = generate_csv_handle(csv_path)

    print('===== TEST INFO =====')
    print('data dir = {}'.format(data_dir))
    print('masker path = {}'.format(masker_path))
    print('classifier path = {}'.format(classifier_path))
    print('csv path = {}'.format(csv_path))
    print('======================')

    print()

    test_gen = TestDataset(os.path.join(data_dir, 'test/'))
    test_dataiter = DataLoader(test_gen, batch_size=32, shuffle=True)
    print('[INFO]generate datasets ok')

    masker_model, classifier_model = make_model(masker_path, classifier_path)
    masker_model.to(DEVICE_TEST)
    classifier_model.to(DEVICE_TEST)
    print('[INFO]load model ok')

    masker_model.eval()
    classifier_model.eval()

    with torch.no_grad():
        for i, data in enumerate(test_dataiter):
            print('Test {}th batch'.format(i))
            print()

            images = data[0]
            filenames = data[1]

            masker_pred = masker_model(images)
            masker_output = masker_model.mask
            classifier_pred = classifier_model(masker_output)

            pred_list = classifier_pred.numpy()

            row = []
            for (filename, pred) in zip(filenames, pred_list):
                row.append(filename)
                row.extend(pred)
                csv_write.writerow(row)
                row.clear()

    csv_file.close()
    print('save csv to {}'.format(csv_path))


if __name__ == '__main__':
    #test(data_dir='../data', masker_path='../model/xvgg_masker_Mon_Apr_22_08_20_02_2019.pth',
    #     classifier_path='../model/xvgg_classifier_Mon_Apr_22_08_20_02_2019.pth', csv_path='./result.csv')
    # train(data_dir='../data', epochs=10, show_model=True, masker_path='../model/xvgg_masker_Mon_Apr_22_08_20_02_2019.pth',
    #    classifier_path='../model/xvgg_classifier_Mon_Apr_22_08_20_02_2019.pth')

    if ON_CLIENT is True:
        #train(data_dir=data_dir+'../data', epochs=10, show_model=True)
        test(data_dir=data_dir+'../data', masker_path=data_dir+'../model/xvgg_masker_Mon_Apr_22_08_20_02_2019.pth',
             classifier_path=data_dir+'../model/xvgg_classifier_Mon_Apr_22_08_20_02_2019.pth', csv_path='./result.csv')
    else:
        fire.Fire()
